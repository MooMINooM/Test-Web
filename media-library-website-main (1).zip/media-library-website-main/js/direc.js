// js/direc.js

export const STATIC_DIRECTOR_HISTORY_DATA = [
    { no: 1, name: 'นายสมชาย รักเรียน', position: 'ผู้อำนวยการ', start: '1 มิ.ย. 2545', end: '30 ก.ย. 2550' },
    { no: 2, name: 'นางสมหญิง สอนดี', position: 'ผู้อำนวยการ', start: '1 ต.ค. 2550', end: '30 ก.ย. 2558' },
    { no: 3, name: 'นายวิชาการ เก่งกาจ', position: 'ผู้อำนวยการ', start: '1 ต.ค. 2558', end: '30 ก.ย. 2565' },
    // เพิ่มข้อมูลตามจริง...
];
